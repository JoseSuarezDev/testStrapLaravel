<?php echo e($slot); ?>

<?php /**PATH C:\Users\programacion2\web\testStrappLaravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>